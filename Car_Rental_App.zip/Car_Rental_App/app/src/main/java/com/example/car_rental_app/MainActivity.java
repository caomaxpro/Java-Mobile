package com.example.car_rental_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.concurrent.ThreadLocalRandom;


public class MainActivity extends AppCompatActivity {

    String car_model_ford[] = {"Ecosport", "Mustang", "Ranger", "Bronco"};
    String car_model_nissan[] = {"GT_R", "Leaf", "Micra", "Qashqai"};
    String car_model_toyota[] = {"Camry", "C_HR", "Corolla", "Rav4"};
    String car_model_honda[] = {"Accord", "CR_V", "Fit", "HR_V"};
    String car_model_list[] = {};

    double car_rating[] = { 9.6 , 9.5, 5.6, 7.6, 8.1, 4.5, 9.0, 10 };

    
    public void activate_car_model_spinner(String get_car_make[]){
        System.out.println("Hello");

        Spinner car_model_spinner = (Spinner) findViewById(R.id.car_model);
        final TextView display_rating = (TextView) findViewById(R.id.rating);

        final ArrayAdapter<String> myAdapter_2 = new ArrayAdapter<String>(
                MainActivity.this,
                android.R.layout.simple_list_item_1, get_car_make
        );

        myAdapter_2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        car_model_spinner.setAdapter(myAdapter_2);

        car_model_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String get_car_model = myAdapter_2.getItem(position).toLowerCase();

                ImageView car_model_image = (ImageView) findViewById(R.id.car_model_image);
                int img_id = getResources().getIdentifier(get_car_model, "drawable", getPackageName());
                car_model_image.setImageResource(img_id);

                int rad_index = ThreadLocalRandom.current().nextInt(0, car_rating.length);
                display_rating.setText(String.format("%.1f", car_rating[rad_index]));
        }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner car_make = (Spinner) findViewById(R.id.car_make);

        final ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(
                MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.car_make)
        );

        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        car_make.setAdapter(myAdapter);

        car_make.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String display_car_make = String.format(myAdapter.getItem(position));

                System.out.println(display_car_make.toLowerCase());

                switch (display_car_make.toLowerCase()){
                    case "nissan":
                        car_model_list = car_model_nissan;
                        break;

                    case "toyota":
                        car_model_list = car_model_toyota;
//                        activate_car_model_spinner(car_model_list);
                        break;

                    case "honda":
                        car_model_list = car_model_honda;
//                        activate_car_model_spinner(car_model_list);
                        break;

                    case "ford":
                        car_model_list = car_model_ford;
//                        activate_car_model_spinner(car_model_list);
                        break;
                }

                activate_car_model_spinner(car_model_list);

                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(MainActivity.this, display_car_make, duration);
                toast.show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        Button get_rental_fee = (Button) findViewById(R.id.rental_fee_btn);
        final EditText get_rent_day = (EditText) findViewById(R.id.get_rent_day);

        final TextView display_rental_fee;
        display_rental_fee = (TextView) findViewById(R.id.total_pice);

        get_rental_fee.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                double rental_fee_each_day = 15.3;
                int rent_day = Integer.parseInt(get_rent_day.getText().toString());
                double subtotal = rent_day * rental_fee_each_day;
                double total = subtotal + (subtotal * 0.13);

                display_rental_fee.setText(String.format("%.2f", total));
            }
        });

    }

}